package starter.utils;

public class JsonSchema {
    public static final String Login_Response_Schema = "schema/Login_Schema.json";
    public static final String Login_Invalid_Email_Response_Schema = "schema/Login_Invalid_Email_Schema.json";
    public static final String Login_Invalid_Password_Response_Schema = "schema/Login_Invalid_Password_Schema.json";}
